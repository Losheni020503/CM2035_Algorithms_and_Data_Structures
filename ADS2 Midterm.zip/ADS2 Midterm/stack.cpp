#include <iostream>
#include <stack>
#include <cctype>
#include <cmath>
using namespace std;

const int MAX_VARIABLES = 26;

int variables[MAX_VARIABLES] = {0};

int evaluatePostfix(string exp) {
    stack<int> st;

    for (int i = 0; i < exp.size(); ++i) {
        if (isdigit(exp[i])) {
            st.push(exp[i] - '0');
        } else if (isalpha(exp[i])) {
            st.push(variables[exp[i] - 'A']);
        } else {
            int val1 = st.top();
            st.pop();
            int val2 = st.top();
            st.pop();
            switch (exp[i]) {
                case '+':
                    st.push(val2 + val1);
                    break;
                case '-':
                    st.push(val2 - val1);
                    break;
                case '*':
                    st.push(val2 * val1);
                    break;
                case '/':
                    st.push(val2 / val1);
                    break;
                case '%':
                    st.push(val2 % val1);
                    break;
                case '^':
                    st.push(pow(val2, val1));
                    break;
                case '=':
                    st.push(val2 == val1);
                    break;
                // Custom operator symbols that I created 
                case '@':
                    st.push(val2 * 2 + val1);
                    break;
                case '#':
                    st.push(val2 - val1 * 3);
                    break;
                case '&':
                    st.push(val2 + val1 / 2);
                    break;
            }
        }
    }
    return st.top();
}

int main() {
    string exp;
    cout << "Enter postfix expression: ";
    cin >> exp;

    for (char &c : exp) {
        if (isalpha(c)) {
            cout << "Enter value for variable " << c << ": ";
            cin >> variables[c - 'A'];
        }
    }

    cout << "Postfix evaluation: " << evaluatePostfix(exp) << endl;
    return 0;
}

